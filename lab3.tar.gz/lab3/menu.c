/******************************************************************************/
/*                                                                            */
/*  FILE NAME               :  menu.c                                         */
/*  PRINCIPAL AUTHOR        :  Suweijiang                                     */
/*  SUBSYSTEM NAME          :  menu                                           */
/*  MODULE NAME             :  menu                                           */
/*  LANGUAGE                :  C                                              */
/*  TARGET ENVIRONMENT      :  ANY                                            */
/*  DATE OF FIRST RELEASE   :  2014/09/09                                     */
/*  DESCRIPTION             :  This is a menu program                         */
/******************************************************************************/

/*
 *  Revision log:
 *
 *  Created by Suweijiang, 2014/09/09
 *
 */

#include<stdio.h>
#include<stdlib.h>
#include "menu.h"

#define CMD_MAX_LEN 128
#define SUCCESS 0
#define FAILURE (-1)

/* CreateMenu */
tTable * CreateMenu()
{
    tTable * pTable = NULL;
    return pTable;
}

/* add cmd */
int AddCmd(tLinkTable * head, tDataNode * tNode)
{
    if(head == NULL || tNode == NULL)
    {
        return FAILURE;
    }
    else
    {
        return SUCCESS;
    }
}

/* MenuStart */
int MenuStart(tLinkTable * head)
{
    while(1)
    {
	if(head == NULL)
	{
	    return FAILURE;
            break;
	}
	else
	{
	    return SUCCESS;
            break;
	}
    }
}

/* InitMenuData */
int InitMenuData(tTable * pTable,tLinkTable * head)
{
    if(pTable == NULL || head == NULL)
    {
	return FAILURE;
    }
    else
    {
	return SUCCESS;
    }
}

/* Delete Menu */
int DeleteMenu(tTable * pTable)
{
    if(pTable == NULL)
    {
        return FAILURE;
    }
    else
    {
	return SUCCESS;
    }
}

/* show all cmd in linktable */
int ShowAllCmd(tLinkTable * head)
{
    if(head == NULL)
    {
	return FAILURE;
    }
    else
    {
	return SUCCESS;
    }
}

/* delete one cmd */
int DelOneCmd(tLinkTable * head, tDataNode *tNode)
{
    if(head == NULL || tNode == NULL)
    {
	return FAILURE;
    }
    else
    {
	return SUCCESS;
    }
}

/* find a cmd in the linktable and return the datanode pointer */
tDataNode* FindCmd(tLinkTable * head, char * cmd)
{
    
}
