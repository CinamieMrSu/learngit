/******************************************************************************/
/*                                                                            */
/*  FILE NAME               :  testcase.c                                     */
/*  PRINCIPAL AUTHOR        :  Suweijiang                                     */
/*  SUBSYSTEM NAME          :  menu                                           */
/*  MODULE NAME             :  testcase                                       */
/*  LANGUAGE                :  C                                              */
/*  TARGET ENVIRONMENT      :  ANY                                            */
/*  DATE OF FIRST RELEASE   :  2014/09/21                                     */
/*  DESCRIPTION             :  test for menu program                          */
/******************************************************************************/

/*
 *  Revision log:
 *
 *  Created by Suweijiang, 2014/09/21
 *
 */

#include<stdio.h>
#include<stdlib.h>
#include"menu.h"

#define debug
#define SUCCESS 0
#define FAILURE (-1)

int results[19] = {1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1};
char *info[19] =
{
    "TC1: Create a menu.",
    "TC2.1: Add cmd to an empty linktable.",
    "TC2.2: Add cmd that not available for an empty linktable.",
    "TC2.3: Add cmd that not available for an exist linktable.",
    "TC2.4: Add cmd to an exist linktable.",
    "TC3.1: Start the menu for an empty linktable.",
    "TC3.2: Start the menu for an exist linktable.",
    "TC4.1: Init menu data with an empty linktable and an empty table.",
    "TC4.2: Init menu data with an empty linktable and an exist table.",
    "TC4.3: Init menu data with an exist linktable and an empty table.",
    "TC4.4: Init menu data with an exist linktable and an exist table.",
    "TC5.1: Delete the menu for an empty linktable.",
    "TC5.2: Delete the menu for an exist linktable.",
    "TC6.1: Show all cmd from an empty linktable.",
    "TC6.2: Show all cmd from an exist linktable.",
    "TC7.1: Delete one cmd from an empty linktable.",
    "TC7.2: Delete one cmd that not tNode from an empty linktable.",
    "TC7.3: Delete one cmd that not tNode from an exist linktable.",
    "TC7.4: Delete one cmd from an exist linktable.",
    
};

/* main program */
int main()
{ 
    int i;
    tTable * p = CreateMenu();
    if(p != NULL)
    {
	printf("TC1 SUCCESS\n");
        results[1] = 0;
    }
    tLinkTable *head = NULL;
    tLinkTable *Head = (tLinkTable *)malloc(sizeof(tLinkTable));
    tDataNode *tnode = NULL;
    tDataNode *tNode = (tDataNode *)malloc(sizeof(tDataNode)); 
    tTable *ptable = NULL;
    tTable *pTable = (tTable *)malloc(sizeof(tTable));
    char cmd[] = "help";
    int ret = AddCmd(head, tNode);
    if(ret == SUCCESS)
    {
	printf("TC2.1 SUCCESS\n");
        results[2] = 0;
    }
    ret = AddCmd(head, tnode);
    if(ret == SUCCESS)
    {
	printf("TC2.2 SUCCESS\n");
        results[3] = 0;
    }
    ret = AddCmd(Head, tnode);
    if(ret == SUCCESS)
    {
	printf("TC2.3 SUCCESS\n");
        results[4] = 0;
    }
    ret = AddCmd(Head, tNode);
    if(ret == SUCCESS)//yes
    {
	printf("TC2.4 SUCCESS\n");
        results[5] = 0;
    }
    ret = MenuStart(head);
    if(ret == SUCCESS)
    {
	printf("TC3.1 SUCCESS\n");
        results[6] = 0;
    }
    ret = MenuStart(Head);
    if(ret == SUCCESS)//yes
    {
	printf("TC3.2 SUCCESS\n");
        results[7] = 0;
    }
    ret = InitMenuData(ptable, head);
    if(ret == SUCCESS)
    {
	printf("TC4.1 SUCCESS\n");
        results[8] = 0;
    }
    ret = InitMenuData(pTable, head);
    if(ret == SUCCESS)
    {
	printf("TC4.2 SUCCESS\n");
        results[9] = 0;
    }
    ret = InitMenuData(ptable, Head);
    if(ret == SUCCESS)
    {
	printf("TC4.3 SUCCESS\n");
        results[10] = 0;
    }
    ret = InitMenuData(pTable, Head);
    if(ret == SUCCESS)//yes 
    {
	printf("TC4.4 SUCCESS\n");
        results[11] = 0;
    }
    ret = DeleteMenu(ptable);
    if(ret == SUCCESS)
    {
	printf("TC5.1 SUCCESS\n");
        results[12] = 0;
    }
    ret = DeleteMenu(pTable);
    if(ret == SUCCESS)//yes 
    {
	printf("TC5.2 SUCCESS\n");
        results[13] = 0;
    }
    ret = ShowAllCmd(head);
    if(ret == SUCCESS)
    {
	printf("TC6.1 SUCCESS\n");
        results[14] = 0;
    }
    ret = ShowAllCmd(Head);
    if(ret == SUCCESS)//yes
    {
	printf("TC6.2 SUCCESS\n");
        results[15] = 0;
    }
    ret = DelOneCmd(head, tNode);
    if(ret == SUCCESS)
    {
	printf("TC7.1 SUCCESS\n");
        results[16] = 0;
    }
    ret = DelOneCmd(head, tnode);
    if(ret == SUCCESS)
    {
	printf("TC7.2 SUCCESS\n");
        results[17] = 0;
    }
    ret = DelOneCmd(Head, tnode);
    if(ret == SUCCESS)
    {
	printf("TC7.3 SUCCESS\n");
        results[18] = 0;
    }
    ret = DelOneCmd(Head, tNode);
    if(ret == SUCCESS)//yes 
    {
	printf("TC7.4 SUCCESS\n");
        results[19] = 0;
    }
  
    /* test report */
    printf("test report:\n");
    for(i = 1; i <= 19; i++)
    {
        if(results[i] == 1)
        {
            printf("Testcase Number%d F - %s\n",i,info[i-1]);
        }
    }
}

