This is lab3

Build Procedure 
    $ make
    $ ./testcase
