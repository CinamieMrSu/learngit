/******************************************************************************/
/*                                                                            */
/*  FILE NAME               :  menu.h                                         */
/*  PRINCIPAL AUTHOR        :  Suweijiang                                     */
/*  SUBSYSTEM NAME          :  menu                                           */
/*  MODULE NAME             :  menu                                           */
/*  LANGUAGE                :  C                                              */
/*  TARGET ENVIRONMENT      :  ANY                                            */
/*  DATE OF FIRST RELEASE   :  2014/09/21                                     */
/*  DESCRIPTION             :  This is a menu program                         */
/******************************************************************************/

/*
 *  Revision log:
 *
 *  Created by Suweijiang, 2014/09/21
 *
 */
#ifndef _MENU_H_
#define _MENU_H_
#include"linktable.h"

/* data struct and its operations */
typedef struct DataNode
{
    struct tDataNode * tNext;
    char*   cmd;
    char*   desc;
    int     (*handler)();
}tDataNode;

typedef struct Table
{
    tDataNode * tHead;
    tDataNode * tTail;
    int         SumOfTNode; 
}tTable;
/* CreateMenu */
tTable * CreateMenu();

/* add one cmd */
int AddCmd(tLinkTable * head, tDataNode *tNode);

/* MenuStart */
int MenuStart(tLinkTable * head);

/* DeleteMenu */
int DeleteMenu(tTable * pTable);

/* InitMenuData */
int InitMenuData(tTable * pTable,tLinkTable * head);

/* show all cmd in linktable */
int ShowAllCmd(tLinkTable * head);

/* delete one cmd */
int DelOneCmd(tLinkTable * head, tDataNode *tNode);

/* find a cmd in the linktable and return the datanode pointer */
tDataNode* FindCmd(tLinkTable * head,char * cmd);

#endif /* _MENU_H_ */
