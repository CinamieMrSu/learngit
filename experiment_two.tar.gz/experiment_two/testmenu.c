/******************************************************************************/
/*                                                                            */
/*  FILE NAME               :  testmenu.c                                     */
/*  PRINCIPAL AUTHOR        :  Suweijiang                                     */
/*  SUBSYSTEM NAME          :  menu                                           */
/*  MODULE NAME             :  testmenu                                       */
/*  LANGUAGE                :  C                                              */
/*  TARGET ENVIRONMENT      :  ANY                                            */
/*  DATE OF FIRST RELEASE   :  2014/09/21                                     */
/*  DESCRIPTION             :  test for menu program                          */
/******************************************************************************/

/*
 *  Revision log:
 *
 *  Created by Suweijiang, 2014/09/21
 *
 */
#include <stdio.h>
#include <stdlib.h>
#include "menu.h"

int Help();

#define CMD_MAX_LEN 128
#define DESC_LEN    1024
#define CMD_NUM     10

static tDataNode data[]=
{
    {NULL,"help","this is help cmd!",Help},
    {NULL,"version","menu program v1.0",NULL}
};

tLinkTable * head = NULL;

main()
{
    head = CreateLinkTable();
    AddOneCmd(head,&data[0]);
    AddOneCmd(head,&data[1]);
    while(1)
    {
        char cmd[CMD_MAX_LEN];
        printf("Input a cmd string >");
        scanf("%s",cmd);
        tDataNode *p = FindCmd(head, cmd);
        if(p == NULL)
        {
            printf("This is a wrong cmd!\n");
            continue;
        }
        printf("%s - %s\n", p->cmd, p->desc);
        if(p->handler != NULL)
        {
            p->handler();
        }
    }
}

int Help()
{
    ShowAllCmd(head);
    return 0;
}
