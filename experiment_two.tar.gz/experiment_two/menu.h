/******************************************************************************/
/*                                                                            */
/*  FILE NAME               :  menu.h                                         */
/*  PRINCIPAL AUTHOR        :  Suweijiang                                     */
/*  SUBSYSTEM NAME          :  menu                                           */
/*  MODULE NAME             :  menu                                           */
/*  LANGUAGE                :  C                                              */
/*  TARGET ENVIRONMENT      :  ANY                                            */
/*  DATE OF FIRST RELEASE   :  2014/09/21                                     */
/*  DESCRIPTION             :  This is a menu program                         */
/******************************************************************************/

/*
 *  Revision log:
 *
 *  Created by Suweijiang, 2014/09/21
 *
 */
#include "linktable.h"
#ifndef _MENU_H_
#define _MENU_H_

/* data struct and its operations */
typedef struct DataNode
{
    tLinkTableNode * pNext;
    char*   cmd;
    char*   desc;
    int     (*handler)();
}tDataNode;

/* find a cmd in the linktable and return the datanode pointer */
tDataNode* FindCmd(tLinkTable * head,char * cmd);

/* show all cmd in linktable */
int ShowAllCmd(tLinkTable * head);

/* add one cmd */
int AddOneCmd(tLinkTable * head, tDataNode *tNode);

/* delete one cmd */
int DelOneCmd(tLinkTable * head, tDataNode *tNode);

/* update one cmd */
int UpdateOneCmd(tLinkTable * head, tDataNode *tNode);

#endif /* _MENU_H_ */
