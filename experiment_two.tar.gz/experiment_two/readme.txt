This is a menu program.

Build Procedure 
    $ gcc linktable.c linktable.h menu.c menu.h testmenu.c -o testmenu
    $ ./testmenu # you can input help & version cmd
