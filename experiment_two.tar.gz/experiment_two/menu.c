/******************************************************************************/
/*                                                                            */
/*  FILE NAME               :  menu.c                                         */
/*  PRINCIPAL AUTHOR        :  Suweijiang                                     */
/*  SUBSYSTEM NAME          :  menu                                           */
/*  MODULE NAME             :  menu                                           */
/*  LANGUAGE                :  C                                              */
/*  TARGET ENVIRONMENT      :  ANY                                            */
/*  DATE OF FIRST RELEASE   :  2014/09/09                                     */
/*  DESCRIPTION             :  This is a menu program                         */
/******************************************************************************/

/*
 *  Revision log:
 *
 *  Created by Suweijiang, 2014/09/09
 *
 */

#include<stdio.h>
#include<stdlib.h>
#include "menu.h"

#define SUCCESS 0
#define FAILURE (-1)

/* find a cmd in the linktable and return the datanode pointer */
tDataNode* FindCmd(tLinkTable * head, char * cmd)
{
    tDataNode *pNode = (tDataNode *)GetLinkTableHead(head);
    while(pNode != NULL)
    {
        if(!strcmp(pNode->cmd,cmd))
        {
            return pNode;
        }
        pNode = (tDataNode *)GetNextLinkTableNode(head,(tLinkTableNode *)pNode);
    }
    return NULL;
}

/* show all cmd in linktable */
int ShowAllCmd(tLinkTable * head)
{
    tDataNode *pNode = (tDataNode *)GetLinkTableHead(head);
    while(pNode != NULL)
    {
        printf("%s - %s\n", pNode->cmd, pNode->desc);
        pNode = (tDataNode *)GetNextLinkTableNode(head,(tLinkTableNode *)pNode);
    }
    return SUCCESS;
}

/* add one cmd */
int AddOneCmd(tLinkTable * head, tDataNode * tNode)
{
    tDataNode *pNode = (tDataNode *)GetLinkTableHead(head);
    while(pNode != NULL)
    {
        if(!strcmp(pNode->cmd,tNode->cmd))
        {
             return FAILURE;
        }
        pNode = (tDataNode *)GetNextLinkTableNode(head,(tLinkTableNode *)pNode);
    }
    if(AddLinkTableNode(head,(tLinkTableNode*)tNode) == 0)
    {
        return SUCCESS;
    }
    else
    {
        return FAILURE;
    }
}

/* delete one cmd */
int DelOneCmd(tLinkTable * head, tDataNode *tNode)
{
    tDataNode *pNode = (tDataNode *)GetLinkTableHead(head);
    while(pNode != NULL)
    {
        if(!strcmp(pNode->cmd,tNode->cmd))
        {
            if(DelLinkTableNode(head,(tLinkTableNode*)tNode) == 0)
            {
                return SUCCESS;
            }
            else
            {
                return FAILURE;
            }
            
        }
        pNode = (tDataNode *)GetNextLinkTableNode(head,(tLinkTableNode *)pNode);
    }
    return FAILURE;
}
